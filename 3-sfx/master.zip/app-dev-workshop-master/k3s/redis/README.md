kubectl apply -k .
