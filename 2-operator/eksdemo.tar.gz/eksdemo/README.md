# eksdemo

a demo eks app for Splunk, built on top of data collected by Splunk Connect for Kubernetes

this app merges the panels in the Splunk Add-on for Kubernetes (https://splunkbase.splunk.com/app/3991/), with the demo app in Splunk's docker-itmonitoring github repo (https://github.com/splunk/docker-itmonitoring/tree/master/app-k8s), and incorporates the Splunk Analysis workspace (https://splunkbase.splunk.com/app/3976/)


This is a work in progess - Some searches and drilldowns are broken, or may require changes in the searches to point at correct macros or sourcetypes

   
